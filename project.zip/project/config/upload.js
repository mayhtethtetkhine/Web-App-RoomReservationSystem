const multer = require("multer");

const option = multer.diskStorage({
    destination: function(req, file, cb)
    {
        cb(null, 'public/upload')
    },
    filename: function(req, file, cb)
    {
        cb(null, file.originalname)
    }, // rename the file

    fileFilter: function (req, file, cb) {
        // Check if the file is an image
        if (file.mimetype.startsWith('image/')) {
          cb(null, true);
        } else {
          cb(new Error('Only image files are allowed!'), false);
        }

    },

});

const upload = multer({storage: option, limits: {fileSize: 1000 * 10000}}).single("filetoupload"); 

module.exports = upload;
