
//viewprofile blueprint
var viewprofile; 
viewprofile = document.getElementById("modalId2");
content = '';
// content += '';
content += '<div class="modal-dialog" role="document">';
content += '<div class="modal-content">';
content += '<div class="modal-header">';
content += '<h5 class="modal-title" id="modalTitleId">Profile</h5>';
content += '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
content += '</div>';
content += '<div class="modal-body">';
content += '<div class="container-fluid">';
content += '<div class="d-flex justify-content-center">';
content += '<img src="/public/image/user-avatar.png" alt="Avatar" class="rounded-circle mx-auto"style="width: 50%;">';
content += '</div>';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'Name';
content += '</div>';
content += '<div class="col">';
content += ' <p>Mr. Student Name</p>';
content += '</div></div>';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'ID';
content += '</div>';
content += '<div class="col">';
content += '<p>6431500000</p>';
content += '</div></div>';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'School';
content += '</div>';
content += '<div class="col">';
content += '<p>School of Information Technology</p>';
content += '</div></div></div></div>';
content += '<div class="modal-footer justify-content-center">';
content += '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>';
content += '<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#modalId3"id="password">Change Password</button>';
content += '<button type="button" class="btn btn-primary" data-bs-dismiss="modal" id="profile">Change ProfilePicture</button>';
content += '</div></div></div>';
viewprofile.innerHTML=content;

//change password blueprint
viewprofile = document.getElementById("modalId3");
content ='';
content += '<div class="modal-dialog" role="document">';
content += '<div class="modal-content">';
content += '<div class="modal-header">';
content += '<h5 class="modal-title" id="modalTitleId">Change Password</h5>';
content += '<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>';
content += '</div>';
content += '<div class="modal-body">';
content += '<div class="container-fluid">';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'Old Password';
content += '</div>';
content += '<div class="col">';
content += '<input type="password" class="form form-control">';
content += '</div>';
content += '</div>';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'New Password';
content += '</div>';
content += '<div class="col">';
content += '<input type="password" class="form form-control">';
content += '</div>';
content += '</div>';
content += '<div class="row mb-2">';
content += '<div class="col">';
content += 'Confirm New Password';
content += '</div>';
content += '<div class="col">';
content += '<input type="password" class="form form-control">';
content += '</div>';
content += '</div>';
content += '</div>';
content += '</div>';
content += '<div class="modal-footer">';
content += '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>';
content += '<button type="button" class="btn btn-primary" id="save">Save</button>';
content += '</div>';
content += '</div>';
content += '</div>';
viewprofile.innerHTML=content;
/* <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalTitleId">Change Password</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container-fluid">
                        <div class="row mb-2">
                            <div class="col">
                                Old Password
                            </div>
                            <div class="col">
                                <input type="password" class="form form-control">
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col">
                                New Password
                            </div>
                            <div class="col">
                                <input type="password" class="form form-control">
                            </div>
                        </div>
                        <div class="row mb-2">
                            <div class="col">
                                Confirm New Password
                            </div>
                            <div class="col">
                                <input type="password" class="form form-control">
                            </div>
                        </div>


                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="save">Save</button>
                </div>
            </div>
        </div> */