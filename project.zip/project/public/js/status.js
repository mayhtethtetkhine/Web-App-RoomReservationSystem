
// for view profile
var view_profile = document.getElementById("view-pro");
console.log(view_profile);
view_profile.addEventListener(
    "click", function (event) {
        view();
    }
);

// for view profile
var change_password = document.getElementById("change-pw");
console.log(change_password);
change_password.addEventListener(
    "click", function (event) {
        change();
    }
);

//sweetalert for view profile
function view() {
    content = "";
    content += '<div style="text-align: left">';
    content += "Name-Surname : Mr.Coconut Goldenplam<br>";
    content += "Student ID : 1212312121<br>";
    content += "School : IT CE<br>";
    content += "</div>";
    Swal.fire({
        title: 'Your Profile',
        html: content,
        imageUrl: '../public/image/user-avatar.png',
        imageWidth: 120,
        imageHeight: 120,
        imageAlt: 'Custom image',
        customClass: {
            size: 'custom-size',
            content: 'left-align'
        },
        showCancelButton: true,
        confirmButtonText: 'Edit',
        cancelButtonText: 'Back',
    }).then(
        (result) => {
            if(result.isConfirmed){
                view_edit();
            }
        }
    );
}

function view_edit() {
    content = '';
    content += '<div style="text-align: center">';
    content += '<button class="btn btn-primary">Change Photo</button><br>';
    content += '<div style="text-align: left">Name-Surname : <input type="text" class="form-control my-2" placeholder="input here.."></div>';
    content += '<div style="text-align: left">School : <input type="text" class="form-control my-2" placeholder="input here.."></div>';
    content += '</div>';
    Swal.fire({
        title: 'Your Profile',
        html: content,
        imageUrl: '../public/image/user-avatar.png',
        imageWidth: 120,
        imageHeight: 120,
        imageAlt: 'Custom image',
        customClass: {
            size: 'custom-size',
            content: 'left-align'
        },
        showCancelButton: true,
        confirmButtonText: 'Change',
        cancelButtonText: 'Cancel',
    }).then(
        (result)=>{
            if(result.isConfirmed){
                view();
            }else{
                view();
            }
        }
    );
}


//sweetalert for change password
function change() {
    content = '';
    content += '<div style="text-align: left">';
    content += 'Current Password : <input type="text" class="form-control my-2" placeholder="input old password">';
    content += 'New Password : <input type="text" class="form-control my-2" placeholder="create new password">';
    content += 'Re-new Password : <input type="text" class="form-control my-2" placeholder="re-input new password">';
    content += '</div>';
    Swal.fire({
        title: 'Change Password',
        html: content,
        customClass: {
            size: 'custom-size',
            content: 'left-align'
        },
        showCancelButton: true,
        confirmButtonText: 'Change',
        cancelButtonText: 'Back',

    });
}