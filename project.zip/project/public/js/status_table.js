//<script>
getUser();
// document.querySelector('#logout').onclick = function () {
//     window.location.href = 'login.html';
// }
async function getUser() {
    try {
        const response = await fetch('/user');
        if (response.ok) {
            const data = await response.json();
            const showname = document.querySelector('#showname');
            const name = document.querySelector('#showNameProfile');
            const userid = document.querySelector('#showIdProfile');
            const School = document.querySelector('#showSchoolProfile');

            showname.innerHTML = data.Name;
            name.innerText = data.Name;
            userid.innerText = data.UserID;
            School.innerText = data.School;

        }

    } catch (err) {
        console.error(err.message);
        Notiflix.Report.failure('Error', err.message, 'Close');
    }
}


document.querySelector('#changepass').onclick = async function () {
    // console.log('clicked');
    oldpass = document.querySelector("#oldpass").value;
    newpass1 = document.querySelector("#newpass1").value;
    newpass2 = document.querySelector("#newpass2").value;

    //  alert(oldpass + newpass1 + newpass2);

    if (oldpass === newpass1) {
        document.querySelector('#message').innerHTML = "Current password cannot be your New password.";
        document.querySelector('#oldpass').value = '';
        document.querySelector('#newpass1').value = '';
        document.querySelector('#newpass2').value = '';
        oldpass = '';
        newpass1 = '';
        newpass2 = '';
    } else {
        if (newpass1 === newpass2) {
            try {
                const response = await fetch('/changepassword', {
                    method: 'PATCH',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ "oldpass": oldpass, "newpass": newpass1 }),
                });

                if (response.ok) {
                    const data = await response.text();

                    if (data === 'Password changed') {
                        Notiflix.Report.success('Success', data, 'OK');
                        document.querySelector('#oldpass').value = '';
                        document.querySelector('#newpass1').value = '';
                        document.querySelector('#newpass2').value = '';

                        document.querySelector('#closemodal').click();



                    } else {
                        console.log(data);
                    }
                } else {
                    const errorMsg = await response.text();
                    throw new Error(`Request failed with status: ${response.status}: ${errorMsg}`);
                }
            } catch (error) {
                console.error('There was a problem with the fetch operation:', error);
                Notiflix.Report.failure('Error', error.message, 'Close');
            }
        } else {
            document.querySelector('#message').innerHTML = "New password and confirm password do not match. ";
            document.querySelector('#oldpass').value = '';
            document.querySelector('#newpass1').value = '';
            document.querySelector('#newpass2').value = '';
            oldpass = '';
            newpass1 = '';
            newpass2 = '';
        }
    }
};




// ========================= modal=========================

var modalId3 = document.getElementById('modalId3');

modalId3.addEventListener('show.bs.modal', function (event) {
    // Button that triggered the modal
    let button = event.relatedTarget;
    // Extract info from data-bs-* attributes
    let recipient = button.getAttribute('data-bs-whatever');

    // Use above variables to manipulate the DOM
});

// ========================= modal 2=========================

var modalId2 = document.getElementById('modalId2');
modalId2.addEventListener('show.bs.modal', function (event) {
    // Button that triggered the modal
    let button = event.relatedTarget;
    // Extract info from data-bs-* attributes
    let recipient = button.getAttribute('data-bs-whatever');
    // Use above variables to manipulate the DOM
});
// document.querySelector('#back').onclick = function () {
//     window.location.href = '/';
// }

async function backDash() {
    try {
        const response = await fetch('/user');
        if (response.ok) {
            const data = await response.json();

            if (data.Role == 0) {
                window.location.replace('/reserve');
            }

            else {
                window.location.replace('/');

            }

        }

    } catch (err) {
        console.error(err.message);
        Notiflix.Report.failure('Error', err.message, 'Close');
    }
}

// async function backDash() {
//     try {
//         const response = await fetch('/user');
//         if (response.ok) {
//             const data = await response.json();

//             if (data.Role == 0) {
//                 window.location.replace('/student');
//             }

//             else if (data.Role == 0) {
//                 window.location.replace('/reserve');

//             }

//             else {
//                 window.location.replace('/');

//             }
//         }
//     } catch (err) {
//         console.error(err.message);
//         Notiflix.Report.failure('Error', err.message, 'Close');
//     }
// }


//</script>


/*=======================================================

This code below designed by Irawin Wetweerapong 6431501157 CE

========================================================*/

//getting space to write table
table_status = document.getElementById("container-custom");

//getting cancel button (but first do null to it first then getting button later)
let _cancelButtons;

//this value for getting source table
let table_t = "";

//this value for getting default table
let table_table = "";

//this value for show cancel button yes or not?
let sw_button = false;
let no_button = 0;
let button_list = [];

//this line for start get data
getTable();

//this function for getting data from database and start create table
async function getTable() {
    try {
        const response = await fetch('/statuslist');
        if (response.ok) {
            const data = await response.json();

            //for testing data
            // console.log(data);
            //console.log("Test:"+data[0].name);

            //start build table
            table_build(data);
        }

    } catch (err) {
        //in case of any error
        console.error(err.message);
        Notiflix.Report.failure('Error', err.message, 'Close');
    }
}


//this function for combine between default table and source table
function table_blueprint() { 
    table_table = `
<div class="row">
    <div class="col-2"></div> <br>
    <div>
        <table id="_table" class="table table-bordered table-striped">
            <thead class="table-dark">
                <tr>
                    <th>Booking ID</th>
                    <th>Room No.</th>
                    <th>Date</th>
                    <th>Time</th>
                    <th>Status</th>
                    <th>Note</th>
                    <th>Reason / Message </th>
                    <th>Decide </th>
                </tr>
            </thead>
            <tbody>
                ${table_t}
            </tbody>
        </table>
    </div>
    <div class="col-2"></div>
</div>
`;
}

//this function for build source table from data
function table_build(_data) {
    //reset for in case of rebuild source table
    table_t = "";
    no_button = 0;

    //loop for create each reservation
    for (i = 0; i < _data.length; i++) {
        table_t += "<tr>";
        table_t += "<td>" + _data[i].id + "</td>";
        table_t += "<td>" + _data[i].location + "-" + _data[i].name + "</td>";
        table_t += "<td>" + date_convert(_data[i].reserveddate) + "</td>";
        table_t += "<td>" + slot_convert(_data[i].timeslot) + "</td>";
        table_t += statusStyle(_data[i].status);
        table_t += "<td>" + _data[i].note + "</td>";
        if(_data[i].message == null)
        {
            table_t += "<td>" + "-" + "</td>";

        }
        else
        {
            table_t += "<td>" + _data[i].message + "</td>";

        }
        table_t += showButton(no_button, _data[i].id);
        table_t += "</tr>";
    }

    //generate default table
    table_blueprint();

    //Writing HTML into page
    table_status.innerHTML = table_table;

    //add effect to all cancel button
    eff_button();
}

//this function for convert date_php_form to Year-Month-Date
function date_convert(_dsource) {

    //convert php date to easy date form
    let dateConvert = new Date(_dsource);

    //get year , mouth and date from php date
    year = dateConvert.getFullYear();
    month = dateConvert.getMonth() + 1;
    day = dateConvert.getDate();

    //create output and connect year+month+date
    let output = "";
    output += "" + year + "-";
    output += "" + month + "-";
    output += "" + day;

    //return as string
    return output;
}

function eff_button() {
    let button_create;
    for (i = 0; i < no_button; i++) {
        button_create = document.getElementById("" + i);
        button_list.push(button_create);
        //alert(""+no_button);
        //if(button_list[i])
        button_list[i].onclick = async function (e) {
            e.preventDefault();
            try {
                options = {
                    method: 'POST',
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify(
                        {
                            "id": this.value,
                        }
                    ),
                };
                const response = await fetch('/statusdel', options);
                if (response.ok) {
                    const data = await response.text();
                    //alert(data);
                    //Notiflix.Report.success('Success', data, 'OK');
                    location.reload();
                }
                else if (response.status == 400) {
                    const data = await response.text();

                    //alert(data);
                    //throw Error(data);

                }
                else {
                    const data = await response.text();

                    //alert(data);
                    //throw Error('Connection error');

                }
            } catch (err) {
                console.error(err.message);
                // alert(err.message);
                Notiflix.Report.failure('Error', err.message, 'Close');
            }


            //alert("id = "+button_create.id+" value = "+button_create.value);
        }

    }
}

//this function for show time slot for reservation
function slot_convert(_slot) {

    //create output for getting timeslot
    let output = "";

    //condition for get timeslot
    switch (_slot) {
        case 1://8am-10am

            output += "8:00 - 10:00";
            break;

        case 2://10am-12am

            output += "10:00 - 12:00";
            break;

        case 3://1pm-3pm

            output += "13:00 - 15:00";
            break;

        case 4://3pm-5pm

            output += "15:00 - 17:00";
            break;

        default:

            //do nothing
            break;
    }

    //return as string
    return output;
}


//this function for getting style text on status row and also set cancel button show or not
function statusStyle(_status) {

    //create output for getting HTML design from as string
    let output = "";

    //in case status is "Waiting"
    if (_status == "Waiting") {
        output = `<td class="text-muted">${_status}</td>`;//
        sw_button = true;

        //in case status is "Approved"
    } else if (_status == "Approved") {
        output = `<td class="text-success">${_status}</td>`;
        sw_button = false;

        //in case status is "Decline Reservation"
    } else if (_status == "Declined") {
        output = `<td class="text-danger">${_status}</td>`;
        sw_button = false;

    } else if (_status == "Canceled") {
        output = `<td class="text-danger">${_status}</td>`;
        sw_button = false;

    }

    //return as string
    return output;
}

//this function for writing cancel reservation button
function showButton(number, _id) {
    //create output for getting HTML design as string
    let output = "";

    //for give condition Writing button or not?
    if (sw_button) {
       
            output = `<td><button id="${number}" class="btn btn-danger" value=${_id}>Cancel</button></td>`;

       
        //for counting button
        no_button++;
    }
    else
    {
        output = `<td></td>`;

    }

    //return as string
    return output;
}

// ----------------------------------- Search----------------------------------
function showSearchList() {
    // Get the search input value
    const searchValue = document.getElementById("statusSearchInput").value.toLowerCase();
    

    // Get all rows in the reservation list table
    const rows = document.getElementById("container-custom").getElementsByTagName("tr");

    // Loop through rows to show/hide based on the search input
    for (let i = 0; i < rows.length; i++) {
        const statusCell = rows[i].getElementsByTagName("td")[4]; // Assuming the status information is in the eighth column


        if (statusCell) {
            const statusText = statusCell.innerText.toLowerCase();
            const shouldShow = statusText.includes(searchValue);
            rows[i].style.display = shouldShow ? "table-row" : "none";
        }
    }
}