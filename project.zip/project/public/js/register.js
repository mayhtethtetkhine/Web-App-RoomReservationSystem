/* 
    This code designed by Irawin Wetweerapong 6431501157 CE
*/

begin();
function begin() {
    //javascript start area here
    _default();
}

function _default() {


    formRegister = document.querySelector('#Register');                                                    //getting data
    id = document.getElementById('id');
    FName = document.getElementById('firstname');
    // LName = document.getElementById('lastname');
    school = document.getElementById('school');
    password = document.getElementById('password');
    confirm_password = document.getElementById('con-password');
    captcha_get = document.getElementById('captcha-get');
    // fileImg = document.querySelector('#fileImg');

    htmlWriter = '';                                                                                      //html writer

    warning_id = document.getElementById('warning-id');                                                   //getting warning
    warning_fname = document.getElementById('warning-fname');
   // warning_lname = document.getElementById('warning-lname');
    warning_school = document.getElementById('warning-school');
    warning_password = document.getElementById('warning-password');
    warning_repassword = document.getElementById('warning-repassword');
    warning_captcha = document.getElementById('warning-captcha');

    register_result_get = document.getElementById('register_result_get');                                 //getting display for register result from app.js side

    output = document.querySelector('#random');                                                                   //getting capcha
    generateCaptcha();                                                                                            //capcha activate
}

function allCorrectlyCheck() {
    mistakeCounter = 0;
    //check allInOne check
    if (!nullTest()) correctCounter++;                                 //null value check
    else if (!checkMatchPassword()) mistakeCounter++;                  //match password check
    else if (!checkCaptcha()) mistakeCounter++;                        //capcha correctly check

    if (mistakeCounter == 0)
        return true;
    else
        return false;
}

function _f() {
    return false;
};


function nullTest() {                                                                                     //check null part
    nullCount = 0;          //<--mistake counter (0 = do next process ,more than 0 stop process)
    htmlWriter = '';        //<--reset html writer

    //=============Check null on Student ID=====================//
    if (valueTestTool(id.value)) {

        nullCount++;  //<--mistake count

        //warning display:on
        id.classList.add("is-invalid");
        warning_id.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Enter your ID. ";
        warning_id.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        id.classList.remove("is-invalid");
        warning_id.classList.remove("text-danger");
        htmlWriter = "";
        warning_id.innerText = htmlWriter;
        //ending of warning:off setting command

    }
    //============================================================//
    //==============Check null on Student fist name================//
    if (valueTestTool(FName.value)) {

        nullCount++;    //<--mistake count

        //warning display:on
        FName.classList.add("is-invalid");
        warning_fname.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Enter your name. ";
        warning_fname.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        FName.classList.remove("is-invalid");
        warning_fname.classList.remove("text-danger");
        htmlWriter = "";
        warning_fname.innerText = htmlWriter;
        //ending of warning:off setting command

    }
   
    if (valueTestTool(password.value)) {

        nullCount++;    //<--mistake count

        //warning display:on
        password.classList.add("is-invalid");
        warning_password.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Enter password for your account. ";
        warning_password.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        password.classList.remove("is-invalid");
        warning_password.classList.remove("text-danger");
        htmlWriter = "";
        warning_password.innerText = htmlWriter;
        //ending of warning:off setting command

    }
    //============================================================//
    //=============Check null on Student re-password=================//
    if (valueTestTool(confirm_password.value)) {

        nullCount++;    //<--mistake count

        //warning display:on
        confirm_password.classList.add("is-invalid");
        warning_repassword.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Enter your password again. ";
        warning_repassword.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        confirm_password.classList.remove("is-invalid");
        warning_repassword.classList.remove("text-danger");
        htmlWriter = "";
        warning_repassword.innerText = htmlWriter;
        //ending of warning:off setting command

    }
    //============================================================//
    //=============Check null on Student school=================//
    if (valueTestTool(school.value)) {

        nullCount++;    //<--mistake count

        //warning display:on
        school.classList.add("custom-danger");
        warning_school.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Select your school. ";
        warning_school.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        school.classList.remove("custom-danger");
        warning_school.classList.remove("text-danger");
        htmlWriter = "";
        warning_school.innerText = htmlWriter;
        //ending of warning:off setting command

    }
    //============================================================//
    //=============Check null on captcha=================//
    if (valueTestTool(captcha_get.value)) {

        nullCount++;    //<--mistake count

        //warning display:on
        captcha_get.classList.add("is-invalid");
        warning_captcha.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Enter captcha. ";
        warning_captcha.innerText = htmlWriter;
        //ending of warning:on setting command

    } else {

        //warning display:off
        captcha_get.classList.remove("is-invalid");
        warning_captcha.classList.remove("text-danger");
        htmlWriter = "";
        warning_captcha.innerText = htmlWriter;
        //ending of warning:off setting command

    }
    //============================================================//
    if (nullCount == 0) return true;        //if there are no any mistake on nullCount so keep checking process to another function as true return
    else return false;                  //if there are any mistake on nullCount so stop checking process as false return
}


function valueTestTool(valueTest) {                                                                     //function tool for null check
    return valueTest === null || valueTest === "" || /^\s*$/.test(valueTest);
}


function checkMatchPassword() {                                                                              //check password matching part
    if (password.value === confirm_password.value) {

        //warning display:off
        captcha_get.classList.remove("is-invalid");
        warning_captcha.classList.remove("text-danger");
        htmlWriter = "";
        warning_captcha.innerText = htmlWriter;
        //ending of warning:on setting command

        return true;
    } else {

        //warning display:on
        confirm_password.classList.add("is-invalid");
        warning_repassword.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Student Password and Confirm-password not match !!";
        warning_repassword.innerText = htmlWriter;
        //ending of warning:on setting command

        return false;
    }
}


function generateCaptcha() {                                                                                     //captcha generator
    num = Math.random();
    min = 1000;
    max = 9999;
    result = Math.floor(num * (max - min + 1) + min);
    output.innerText = "Enter Captcha :   " + result;
}

function checkCaptcha() {                                                                                       //captcha collectly check
    if (parseInt(captcha_get.value) === parseInt(result)) {
        //warning display:off
        captcha_get.classList.remove("is-invalid");
        warning_captcha.classList.remove("text-danger");
        htmlWriter = "";
        warning_captcha.innerText = htmlWriter;
        //ending of warning:on setting command

        return true;

    } else {

        //warning display:on
        captcha_get.classList.add("is-invalid");
        warning_captcha.classList.add("text-danger");
        htmlWriter = "";
        htmlWriter += "Captcha incorrect. Try again. ";
        warning_captcha.innerText = htmlWriter;
        //ending of warning:on setting command

        return false;

    }
}

function resultDisplay(register_result) {

    register_result_get.classList.remove("alert-success");
    register_result_get.classList.remove("alert-warning");
    register_result_get.classList.remove("alert-danger");

    if (register_result == "register_success") {

        //warning display:on
        register_result_get.classList.add("alert-success");
        htmlWriter = "";
        htmlWriter += "Your new account is registered successfully. <br>";
        htmlWriter += '<a id="warp-login" href="javascript:void(0);" onclick="replaceRegisterPage();" class="text-primary">Login</a>';
        register_result_get.innerHTML = htmlWriter;

        //ending of warning:on setting command

    } else if (register_result == "register_repeat") {

        //warning display:on
        register_result_get.classList.add("alert-warning");
        htmlWriter = "";
        htmlWriter += "Your account is already registered. ";
        register_result_get.innerText = htmlWriter;
        //ending of warning:on setting command

    } else if (register_result == "register_connection_failed") {

        //warning display:on
        register_result_get.classList.add("alert-danger");
        htmlWriter = "";
        htmlWriter += "Server connection failed. ";
        register_result_get.innerText = htmlWriter;
        //ending of warning:on setting command

    }
}


formRegister.onsubmit = async function (e) {                                                            //effect on event function
    e.preventDefault();
    if (allCorrectlyCheck()) {
        try {
            options = {
                method: 'POST',
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(
                    {
                        "id": id.value,
                        "Name": FName.value,
                        "password": password.value,
                        "school": school.value,
                        // "image": fileImg.value
                    }
                ),
            };
            const response = await fetch('/register', options);
            if (response.ok) {
                const data = await response.text();
                Notiflix.Report.success('Success', data, 'Login now', function()
                {
                    //clear and go to login
                    window.location.replace('/');
                    // alert('ok');
                });
                // resultDisplay(data);
                //alert(data);
              //  Notiflix.Report.success('Success', data, 'OK');

            }
            else if (response.status == 400) {
                const data = await response.text();
                document.getElementById('id').value = '';
                // resultDisplay(data);
                //alert(data);
                throw Error(data);

            }
            else {
                const data = await response.text();
                // resultDisplay(data);
                // alert(data);
                throw Error('Connection error');

            }

        } catch (err) {
            console.error(err.message);
            //  alert(err.message);
           Notiflix.Report.failure('Error', err.message, 'Close');
        }


    }
}


// function replaceRegisterPage()
// {
//     var newURL = '/login'; // Replace with the URL of your registration page
//     window.location.replace(newURL);
// }
