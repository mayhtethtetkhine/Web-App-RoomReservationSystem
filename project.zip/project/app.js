const { log } = require('console');
const express = require('express');
const path = require('path');
const con = require('./config/db');
const app = express();
const bcrypt = require('bcrypt');
const session = require("express-session");
const memorystore = require("memorystore")(session);
const upload = require("./config/upload");

app.use('/public', express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

//photo
const multer = require("multer");

//set up session ========================
app.use(session({
  cookie: { maxAge: 24 * 60 * 60 * 1000 },
  secret: 'reservation',
  resave: false,
  saveUninitialized: true,
  store: new memorystore({
    checkPeriod: 24 * 60 * 60 * 1000
  })
}));

// log out ==================

app.get("/logout", function (req, res)
{
  req.session.destroy(function (err)
  {
    if (err)
    {
      console.error(err.message);
      res.status(500).send('Log Out Error');
    }
    else
    {
      res.redirect('/');
    }
  })

});


//change password =======================================

app.patch('/changepassword', (req, res) =>
{
  const oldpass = req.body.oldpass;
  const newpass = req.body.newpass;

  // Validate the current password (you may also check if the user is authenticated)

  // Update the user's password
  const id = req.session.UserID; // Replace with the actual user's ID
  const sql_select = `SELECT password from account WHERE id = ?`;

  con.query(sql_select, [id], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }
    else if (results.length != 1)
    {
      res.status(400).send('ID not found');
      res.redirect('/');
    }
    else
    {

      bcrypt.compare(oldpass, results[0].password, function (err, same)
      {
        if (err)
        {
          console.error(err);
          res.status(500).send('Password encryption error');
        }
        else
        {
          if (same)
          {
            //Crypt the password area
            bcrypt.hash(newpass, 10, function (err, hash)
            {
              if (err)
              {
                console.error('Error hashing the password:', err);
                res.status(500).send('Password encryption error');

              } else
              {
                // console.log('Hashed Password:', hash);
                password_crypt = hash;
                const sql_update = `UPDATE account SET password = ? WHERE id = ?`;
                con.query(sql_update, [password_crypt, id], function (err, results)
                {
                  if (err)
                  {
                    console.error(err);
                    res.status(500).send('DB error');
                  }
                  else
                  {
                    //console.log("Password changed");
                    res.status(200).send('Password changed');
                  }
                }
                );

              }
            });

          }
          else
          {
            console.error('Password not the same');
            res.status(400).send('Wrong current password');
          }
        }
      });

    }
  });


});



// student get status page ===============================

app.get('/status', function (req, res)
{
  if (req.session.Role == 0)
  {
    res.sendFile(path.join(__dirname, 'views/status.html'));
  }
  else
  {
    res.redirect('/');
  }

})




// functions===============================================
// login function==

function login(req, res)
{
  const { id, password } = req.body;
  const sql = `SELECT id, name, password, school, role FROM account WHERE id = ? `;

  con.query(sql, [id], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }
    else if (results.length != 1)
    {
      res.status(400).send('ID not found');
    }
    else
    {
      bcrypt.compare(password, results[0].password, function (err, same)
      {
        if (err)
        {
          console.error(err);
          res.status(500).send('Password encryption error');
        }
        else
        {
          if (same)
          {
            // console.log(results[0]);
            req.session.UserID = results[0].id;
            req.session.Name = results[0].name;
            req.session.Role = results[0].role;
            req.session.School = results[0].school;

            if (results[0].role == 0)
            {
              //res.send('Login successful');
              res.send('/student');

            }
            else if (results[0].role == 1)
            {
              res.send('/staff');
            }
            else
            {
              res.send('/lecturer');
            }

          }
          else
          {
            res.status(400).send('Wrong Password');
          }
        }
      })


    }
  }
  );

}

//===============================================

// --------------- Staff Add room /add -----------------

app.post("/add", function (req, res)
{
  const roomname = req.body.roomnameAdd;
  const location = req.body.locationAdd;
  const size = req.body.sizeAdd;
  const status = req.body.statusAdd;
  const photo = req.body.photoAdd;
  // const img = req.body.image;
  // console.log(req.body);

  //sql command to ask
  const sql_test = `SELECT name, location FROM room WHERE name =? AND location =? ;`;                         //asking database for check repeat
  con.query(sql_test, [roomname, location], function (err, results)
  {

    if (err)
    {                                                                                     //if sql command error or can't getting database

      //sending result to register.html
      return res.status(500).send("DB connection failed");

    }
    if (results.length != 0)
    {                                                                      //check repeat account

      //sending result to register.html
      return res.status(400).send("Room already exists ");

    } else
    {
      const sql = 'INSERT INTO room (name, location, size,status,photo)VALUES (?, ?, ?,?,?);';              //adding data part
      con.query(sql, [roomname, location, size, status, photo], function ()
      {

        if (err)
        {                                                                                     //if sql command error or can't getting database

          //sending result to register.html
          return res.status(500).send("DB connection failed");

        }
        else
        {
          res.status(200).send("Room added");
        }

      });


    }
  });
}
);


//----------- staff get rooms ------------------------

app.get("/roomlist", function (_req, res)
{
  const sql = 'SELECT * FROM room';

  con.query(sql, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      res.json(results);
    }
  })

});

//------------- staff edit room ---------------------


app.patch('/edit/:id', (req, res) =>
{
  const id = req.params.id;
  const name = req.body.roomnameEdit;
  const location = req.body.locationEdit;
  const size = req.body.sizeEdit;
  // const photo = req.body.photoEdit;

  // const status = req.body.statusEdit;

  // const sqlcheck = `SELECT id FROM room WHERE name = ? AND location = ?`;
  // con.query(sqlcheck, [name, location], function (err, results)
  // {

  //   if (err)
  //   {
  //     console.log(err);
  //     return res.status(500).send("DB connection failed");
  //   }
  //   else if (results.length != 0)
  //   {
  //     return res.status(400).send("Room already exists");
  //   }
  //   else
  //   {

  const sql = `UPDATE room SET name = ?, location = ?, size = ? WHERE id = ?`;

  con.query(sql, [name, location, size, id], function (err, results)
  {
    // console.log(results);

    if (err)
    {  //if sql command error or can't getting database
      //sending result
      console.log(err);
      return res.status(500).send("DB connection failed");
    }
    else
    {
      if (results.affectedRows != 1)
      {
        return res.status(400).send("Room update failed");

      }
      else
      {
        res.status(200).send("Room Edited");

      }
    }

  });

  //}
  // });



});

//--------------- change status --------------------


app.patch('/changestatus', (req, res) =>
{
  const id = req.body.roomidStatus;
  const status = req.body.replaceStatus;
  // const status = req.body.statusEdit;

  const sqlcheck = `UPDATE room SET status = ? WHERE id = ? `;
  con.query(sqlcheck, [status, id], function (err, results)
  {

    if (err)
    {
      console.log(err);
      return res.status(500).send("DB connection failed");
    }
    else if (results.affectedRows != 1)
    {
      console.log(err);
      return res.status(400).send("Status update failed");
    }
    else
    {
      res.status(200).send("Room status updated");
    }
  });

});



// ------------- Get user info --------------
app.get("/user", function (req, res)
{
  // req.session.UserID = results[0].id;
  // req.session.Name = results[0].name;
  // req.session.Role = results[0].role;
  // req.session.School = results[0].school;

  // console.log(req.session.UserID, req.session.Name);
  res.json({ "UserID": req.session.UserID, "Name": req.session.Name, "School": req.session.School, "Role": req.session.Role });
});

// ---------------- GET student reservation page -----------

app.get('/reserve', function (req, res)
{
  if (req.session.Role == 0)
  {
    res.sendFile(path.join(__dirname, 'views/student-browse-room.html'));
  }
  else
  {
    res.redirect('/');
  }

})

//----------- make reservation student reserve post -----------------------

app.post("/reserve", function (req, res)
{
  const date = req.body.date;
  const dateR = req.body.dateR;
  const slot = req.body.timeslot;
  const note = req.body.note;
  const status = req.body.status;
  const roomid = req.body.roomid;
  const studentid = req.body.studentid;
  // console.log(req.body);


  const sql = 'INSERT INTO reservation (date, reserveddate, timeslot, note,status, roomid, studentid) VALUES (?,?,?,?,?,?,?);';              //adding data part
  con.query(sql, [date, dateR, slot, note, status, roomid, studentid], function (err, result)
  {
    if (err)
    { //if sql command error or can't getting database
      //sending result to register.html
      return res.status(500).send("DB connection failed");
    }
    else if (result.affectedRows != 1)
    {
      return res.status(400).send("Reservation error");
    }
    else
    {
      res.status(200).send("Reservation request sent");
    }

  });


});



// --------------- student reserve list -----------------------

app.get("/reservelist", function (_req, res)
{
  const sql = 'SELECT * FROM room WHERE status != "Disabled"';

  con.query(sql, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      res.json(results);
    }
  })

});

//-------------- check reserve free ------------------


app.get('/reservecheckfree/:id/:date/:slot', (req, res) =>
{
  const roomid = req.params.id;
  const date = req.params.date;
  const slot = req.params.slot;
  const sql = 'SELECT * FROM room, reservation WHERE reservation.reserveddate = ? AND reservation.timeslot = ? AND reservation.roomid = room.id AND room.id = ? ';

  con.query(sql, [date, slot, roomid], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else if (results.length > 0)
    {
      let count = 0;
      for (result of results)
      {

        // console.log(result.status);
        if (result.status == 'Approved' || result.status == 'Waiting')
        {
          count++;
        }

      }
      if (count > 0)
      {
        res.send("Reserved");
      }
      else
      {
        res.send("Free");
      }

    }
    else if (results.length == 0)
    {
      res.send(`Free`);
    }

    else
    {
      console.error(err);
      res.send(err);
    }
  })

});

//=========== root ==== login===

app.get('/', function (req, res)
{

  if (req.session.Role == 0)
  {
    res.redirect('/student');
  }
  else if (req.session.Role == 1)
  {
    res.redirect('/staff');
  }
  else if (req.session.Role == 2)
  {
    res.redirect('/lecturer');
  }
  else
  {
    res.sendFile(path.join(__dirname, 'views/login.html'));
  }
})

app.post('/', function (req, res)
{
  login(req, res);

});


// staffbrowse get

app.get('/staffbrowse', function (req, res)
{
  if (req.session.Role == 1)
  {
    res.sendFile(path.join(__dirname, 'views/staff-browse-room.html'));
  }
  else
  {
    res.redirect('/');
  }

})

// -------------room show (student-browse-room, lecturer reservations) -----------------

app.get('/roomshow/:roomid', function (req, res)
{
  roomid = req.params.roomid;
  const sql = 'SELECT * FROM room WHERE id = ?';

  con.query(sql, [roomid], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else if (results.length == 1)
    {
      res.json(results);
    }
  });

}
);

// -------------- lecturer reservation get ---------------

app.get('/lecturerreservation', function (req, res)
{
  if (req.session.Role == 2)
  {
    res.sendFile(path.join(__dirname, 'views/lecturer-reservations.html'));
  }
  else
  {
    res.redirect('/');
  }
});


// lecturerbrowse get lecturer-browse-room Ice part -------------------------------------------

app.get('/lecturerbrowse', function (req, res)
{
  if (req.session.Role == 2)
  {
    res.sendFile(path.join(__dirname, 'views/lecturer-browse-room.html'));
  }
  else
  {
    res.redirect('/');
  }

})



//register.html  =========== GET ====

app.get('/register', function (_req, res)
{
  //  res.redirect('/student');
  res.sendFile(path.join(__dirname, 'views/register.html'));
});

//register post ===============


app.post("/register", function (req, res)
{
  const id = req.body.id;
  const Name = req.body.Name;
  const school = req.body.school;
  const password = req.body.password;
  // const img = req.body.image;
  password_crypt = "";
  // console.log(req.body);

  //sql command to ask
  const sql_test = `SELECT id, name FROM account WHERE id =? ;`;                         //asking database for check repeat
  con.query(sql_test, [id], function (err, results)
  {          //<--extract JSON value to sql form and do function

    if (err)
    {                                                                                     //if sql command error or can't getting database

      //sending result to register.html
      return res.status(500).send("register_connection_failed");

    }
    if (results.length != 0)
    {                                                                      //check repeat account

      //sending result to register.html
      return res.status(400).send("register_repeat");

    } else
    {                                                                                         //adding new user account part
      //sql command for add data

      //Crypt the password area
      bcrypt.hash(password, 10, function (err, hash)
      {
        if (err)
        {
          console.error('Error hashing the password:', err);
          res.status(500).send('Password encryption error');

        } else
        {
          // console.log('Hashed Password:', hash);
          password_crypt = hash;
          // console.log('Password_crypt = ' + password_crypt);
          const sql = 'INSERT INTO account (id, name, school,password)VALUES (?, ?, ?,?);';              //adding data part
          con.query(sql, [id, Name, school, password_crypt], function ()
          {

            if (err)
            {                                                                                     //if sql command error or can't getting database

              //sending result to register.html
              return res.status(500).send("register_connection_failed");

            }
            else
            {
              res.status(200).send("register_success");
            }

          });   //<--extract JSON value to sql form and do nothing
        }
      });


      //sending result to register.html
      //  return 

    }

  });
});
//=================================================================
//student-main.html=====

app.get('/student', function (req, res)
{
  if (req.session.Role == 0)
  {
    res.sendFile(path.join(__dirname, 'views/student-main.html'));
  }
  else
  {
    res.redirect('/');
  }
});


//=============

// ============ admin or staff GET===============

app.get('/staff', function (req, res)
{
  if (req.session.Role == 1)
  {
    res.sendFile(path.join(__dirname, 'views/staff-main.html'));
  }
  else
  {
    res.redirect('/');
  }

})

// =============== lecturer GET ================

app.get('/lecturer', function (req, res)
{
  if (req.session.Role == 2)
  {
    res.sendFile(path.join(__dirname, 'views/lecturer-main.html'));
  }
  else
  {
    res.redirect('/');
  }
})

//history GET================

app.get('/history', function (req, res)
{
  if (req.session.Role == 2 || req.session.Role == 1)
  {
    res.sendFile(path.join(__dirname, 'views/history.html'));
  }
  else
  {
    res.redirect('/');
  }
})

//--------------- /studentdash --- student dashboard get ---------------


app.get('/studentdash', function (req, res)
{
  returnjson = [{}];
  senddatacount = 0;

  const sql_available = `SELECT COUNT(room.id) AS roomcount FROM room WHERE room.status = 'Enabled' `;
  con.query(sql_available, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].available = results[0].roomcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

  });
  const sql_disabled = `SELECT COUNT(room.id) AS roomcount FROM room WHERE room.status = 'Disabled' `;
  con.query(sql_disabled, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].disabled = results[0].roomcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

  });
  const sql_total = `SELECT COUNT(room.id) AS roomcount FROM room `;
  con.query(sql_total, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].total = results[0].roomcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }
    if (senddatacount == 3)
    {
      res.json(returnjson);
    }
    else
    {
      res.status(500).send('Cannot fetch data');
    }

  });


}
);


// -------------- staff dash -------------------------------


app.get('/staffdash/:date', function (req, res)
{
  const date = req.params.date;

  returnjson = [{}];
  senddatacount = 0;

  const sql_reservations = `SELECT COUNT(id) AS rcount FROM reservation WHERE date = ? `;
  con.query(sql_reservations, [date], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].reservations = results[0].rcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

  });
  const sql_today = `SELECT COUNT(id) AS rcount FROM reservation WHERE status = 'Approved' AND reserveddate = ? `;
  con.query(sql_today, [date], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].today = results[0].rcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

  });
  const sql_disabled = ` SELECT COUNT(room.id) AS roomcount FROM room WHERE status = 'Disabled' `;
  con.query(sql_disabled, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].disabled = results[0].roomcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }


  });
  const sql_rooms = `SELECT COUNT(room.id) AS roomcount FROM room WHERE status = 'Enabled'  `;
  con.query(sql_rooms, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].rooms = results[0].roomcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }
    if (senddatacount == 4)
    {
      // console.log(returnjson);
      res.json(returnjson);
    }
    else
    {
      res.status(500).send('Cannot fetch data');
    }


  });

}
);

// --------------- lecturer reservation list -------

app.get("/reservationlist", function (_req, res)
{
  //const sql = `SELECT reservation.*, room.name, room.location FROM room, reservation WHERE status = 'Waiting' AND reservation.roomid = room.id`;


  const sql = `SELECT reservation.*, room.name, room.location
  FROM room
  JOIN reservation ON reservation.roomid = room.id
  WHERE reservation.status = 'Waiting'`;

  //const sql = `SELECT * from reservation`;

  con.query(sql, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      res.json(results);
      console.log(results);
    }
  })

});

// ---------------------- Lecturer Decide Ice part ----------------------

app.patch('/reservations/:decision/:reservationid', (req, res) =>
{

  if (req.session.Role == 2)
  {
    const lid = req.session.UserID;
    const id = req.params.reservationid;
    const rid = parseInt(id);
    const decision = req.params.decision;
    const message = req.body.message;

    // console.log(rid, decision, message);

    const sql = `UPDATE reservation SET status=?, message=?, lecturerid = ? WHERE id = ? ;`;

    con.query(sql, [decision, message, lid, rid], function (err, results)
    {
      if (err)
      {
        console.error(err);
        res.status(500).send('DB error');
      }

      else if (results.affectedRows != 1)
      {
        console.error(err);
        if (decision == "Approved")
        {
          res.status(400).send('Error Approving Reservation');
        }
        else
        {
          res.status(400).send('Error Declining Reservation');
        }

      }
      else
      {
        if (decision == "Approved")
        {
          res.status(200).send('Reservation Approved.');
        }
        else
        {
          res.status(200).send('Reservation Declined.');
        }
      }
    });
  }
  else
  {
    res.redirect('/');

  }



});

//--------------- Status -------- from Win -----------------------


//Status Get=======================================================
// app.get('/status', function (req, res)
// {
//   if (req.session.Role == 0)
//   {
//     res.sendFile(path.join(__dirname, 'views/status.html'));
//   } else
//   {
//     res.sendFile(path.join(__dirname, '/'));

//   }
// })

app.get('/statuslist', function (req, res)
{
  sql_status = "SELECT reservation.id,room.location, room.name, reservation.reserveddate,reservation.timeslot,reservation.status,reservation.note, reservation.message";
  sql_status += " FROM reservation INNER JOIN room ON room.id=reservation.roomid";
  sql_status += " WHERE studentid = '" + req.session.UserID + "' ORDER BY reservation.reserveddate DESC";
  console.log(sql_status);
  con.query(sql_status, null, function (err, results)
  {
    if (err)
    {
      res.status(500).send("connection failed");
    } 
    else
    {
      if (results.length != 0)
      {
        res.status(200).json(results);
      } 
      // else
      // {
      //   res.status(200).send("data not found");
      // }
    }
  })

})

//new api
app.post('/statusdel', function (req, res)
{
  const id = req.body.id;
  const sql_status_del = `DELETE FROM reservation WHERE id = ${id}`;
  //const sql_status_del = `UPDATE reservation SET status='Canceled' WHERE id = ${id}`;
  con.query(sql_status_del, null, function (err)
  {
    if (err)
    {
      return res.status(500).send("delete_status_failed");
    } else
    {
      return res.status(200).send("delete_status_done");
    }
  })
});



// ======================== Upload =============================
app.post('/uploading', function (req, res)
{
  console.log(req.file);

  upload(req, res, function (err)
  {
    if (err)
    {
      console.log(err);
      res.status(500).send('Upload failed');
    } else
    {
      res.send('Upload is successful');
    }

    // console.log(req.body.username);
  });

});





//=====================================================================


app.post("/historylist", function (req, res)
{
  const searchRoom = req.body.room;
  const searchLocation = req.body.location;
  const id = req.session.UserID;
  const role = req.session.Role;

  let sql;
  if (role == 1) // staff
  {
    if (searchRoom || searchLocation)
    {

      sql = `SELECT 
                 reservation.*, 
                 lecturer.name AS lecturername, 
                 lecturer.role, 
                 student.name AS studentname,
                 room.id AS roomid, 
                 room.location, 
                 room.size, 
                 room.name 
            FROM 
                 reservation 
            JOIN 
                 room ON reservation.roomid = room.id 
            JOIN 
                 account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
            JOIN 
                 account AS student ON reservation.studentid = student.id AND student.role = 0 
            WHERE`;

      if (searchRoom)
      {
        sql += ` room.name = '${searchRoom}' AND`;
      }

      if (searchLocation)
      {
        sql += ` room.location = '${searchLocation}' AND`;
      }

      sql = sql.slice(0, -3);
    } else
    {
      sql = `SELECT 
                 reservation.*, 
                 lecturer.name AS lecturername, 
                 lecturer.role, 
                 student.name AS studentname,
                 room.id AS roomid, 
                 room.location, 
                 room.size, 
                 room.name 
            FROM 
                 reservation 
            JOIN 
                 room ON reservation.roomid = room.id 
            JOIN 
                 account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
            JOIN 
                 account AS student ON reservation.studentid = student.id AND student.role = 0;`;

    }


  }

  else // lecturer 
  {
    if (searchRoom || searchLocation)
    {

      sql = `SELECT 
                 reservation.*, 
                 lecturer.name AS lecturername, 
                 lecturer.role, 
                 student.name AS studentname,
                 room.id AS roomid, 
                 room.location, 
                 room.size, 
                 room.name 
            FROM 
                 reservation 
            JOIN 
                 room ON reservation.roomid = room.id 
            JOIN 
                 account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
            JOIN 
                 account AS student ON reservation.studentid = student.id AND student.role = 0 
            WHERE reservation.lecturerid = ? AND`;

      if (searchRoom)
      {
        sql += ` room.name = '${searchRoom}' AND`;
      }

      if (searchLocation)
      {
        sql += ` room.location = '${searchLocation}' AND`;
      }

      sql = sql.slice(0, -3);
    } else
    {
      sql = `SELECT 
                 reservation.*, 
                 lecturer.name AS lecturername, 
                 lecturer.role, 
                 student.name AS studentname,
                 room.id AS roomid, 
                 room.location, 
                 room.size, 
                 room.name 
            FROM 
                 reservation 
            JOIN 
                 room ON reservation.roomid = room.id 
            JOIN 
                 account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
            JOIN 
                 account AS student ON reservation.studentid = student.id AND student.role = 0
            WHERE reservation.lecturerid = ?;`;

    }
  }

  con.query(sql, [id], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    } else
    {
      res.json(results);
    }
  });
});




// ------------------------------------------- new search--------------------------------------------
// when free
app.post("/historylist/all", function (req, res)
{
  // const sql = `SELECT reservation.*, account.id AS accountid, account.name AS lecturername, account.role, room.id AS roomid, room.location, room.size, room.name FROM reservation JOIN room ON reservation.roomid = room.id JOIN account ON reservation.lecturerid = account.id AND account.role = 2`;
  const id = req.session.UserID;
  const role = req.session.Role;

  if (role == 1) // staff role -> see everything 
  {
    sql = `SELECT 
  reservation.*, 
  lecturer.name AS lecturername, 
  lecturer.role, 
  student.name AS studentname,
  room.id AS roomid, 
  room.location, 
  room.size, 
  room.name 
 FROM 
  reservation 
 JOIN 
  room ON reservation.roomid = room.id 
 JOIN 
  account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
 JOIN 
  account AS student ON reservation.studentid = student.id AND student.role = 0;`;

  }
  else //if lecturer role -> filter with user id
  {
    sql = `SELECT 
  reservation.*, 
  lecturer.name AS lecturername, 
  lecturer.role, 
  student.name AS studentname,
  room.id AS roomid, 
  room.location, 
  room.size, 
  room.name 
 FROM 
  reservation
 JOIN 
  room ON reservation.roomid = room.id 
 JOIN 
  account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
 JOIN 
  account AS student ON reservation.studentid = student.id AND student.role = 0
WHERE reservation.lecturerid = ?;`;

  }
  con.query(sql, [id], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    } else
    {
      res.json(results);
    }
  });
});

app.get("/historylist", function (req, res)
{
  // const sql = 'SELECT * FROM reservation';

  const id = req.session.UserID;
  const role = req.session.Role;

  if (role == 1) // staff role -> see everything 
  {
    sql = `SELECT 
  reservation.*, 
  lecturer.name AS lecturername, 
  lecturer.role, 
  student.name AS studentname,
  room.id AS roomid, 
  room.location, 
  room.size, 
  room.name 
 FROM 
  reservation 
 JOIN 
  room ON reservation.roomid = room.id 
 JOIN 
  account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
 JOIN 
  account AS student ON reservation.studentid = student.id AND student.role = 0;`;

  }
  else //if lecturer role -> filter with user id
  {
    sql = `SELECT 
  reservation.*, 
  lecturer.name AS lecturername, 
  lecturer.role, 
  student.name AS studentname,
  room.id AS roomid, 
  room.location, 
  room.size, 
  room.name 
 FROM 
  reservation
 JOIN 
  room ON reservation.roomid = room.id 
 JOIN 
  account AS lecturer ON reservation.lecturerid = lecturer.id AND lecturer.role = 2
 JOIN 
  account AS student ON reservation.studentid = student.id AND student.role = 0
WHERE reservation.lecturerid = ?;`;

  }


  con.query(sql, [id], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }
    else
    {
      res.json(results);
    }
  })

});

//---------------------- Lecturer Dash Get ---------------------

app.get('/lecturerdash/:date', function (req, res)
{
  const date = req.params.date;

  returnjson = [{}];
  senddatacount = 0;

  const sql_unresponded = `SELECT COUNT(id) AS rcount FROM reservation WHERE status = 'Waiting' `;
  con.query(sql_unresponded, function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].unresponded = results[0].rcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

  });

  const sql_today = `SELECT COUNT(id) AS rcount FROM reservation WHERE status = 'Approved' AND reserveddate = ? `;
  con.query(sql_today, [date], function (err, results)
  {
    if (err)
    {
      console.error(err);
      res.status(500).send('DB error');
    }

    else
    {
      returnjson[0].today = results[0].rcount;
      //append to returnjson array. 
      // console.log(returnjson);
      senddatacount++;
    }

    if (senddatacount == 2)
    {
      // console.log(returnjson);
      res.json(returnjson);
    }
    else
    {
      res.status(500).send('Cannot fetch data');
    }

  });

}
);



//==================================================================

const PORT = 4000;
app.listen(PORT, function ()
{
  console.log('Server is running at port ' + PORT);
});